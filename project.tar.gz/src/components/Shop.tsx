import { ShoppingBag } from 'lucide-react';

const products = [
  {
    id: 1,
    name: 'Lukisan Original "Jiwa"',
    price: 'Rp 1.500.000',
    size: '40x50 cm',
    medium: 'Acrylic on Canvas',
    src: 'https://images.pexels.com/photos/1193743/pexels-photo-1193743.jpeg?auto=compress&cs=tinysrgb&w=600',
    wa: 'https://wa.me/6280000000000?text=Saya%20ingin%20order%20Lukisan%20Original%20Jiwa',
  },
  {
    id: 2,
    name: 'Lukisan Original "Senja"',
    price: 'Rp 2.000.000',
    size: '60x80 cm',
    medium: 'Oil on Canvas',
    src: 'https://images.pexels.com/photos/2110951/pexels-photo-2110951.jpeg?auto=compress&cs=tinysrgb&w=600',
    wa: 'https://wa.me/6280000000000?text=Saya%20ingin%20order%20Lukisan%20Original%20Senja',
  },
  {
    id: 3,
    name: 'Lukisan Original "Mimpi"',
    price: 'Rp 1.800.000',
    size: '50x70 cm',
    medium: 'Watercolor',
    src: 'https://images.pexels.com/photos/1585325/pexels-photo-1585325.jpeg?auto=compress&cs=tinysrgb&w=600',
    wa: 'https://wa.me/6280000000000?text=Saya%20ingin%20order%20Lukisan%20Original%20Mimpi',
  },
];

export default function Shop() {
  return (
    <section id="shop" className="py-28 px-6 lg:px-10 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-white/40 text-xs tracking-[0.3em] uppercase mb-4">Original Works</p>
          <h2 className="text-white text-4xl md:text-5xl font-bold">Shop</h2>
          <div className="w-16 h-px bg-white/20 mx-auto mt-6" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {products.map((product) => (
            <div
              key={product.id}
              className="group border border-white/10 rounded-2xl overflow-hidden hover:border-white/30 transition-colors duration-300 bg-white/5"
            >
              <div className="overflow-hidden aspect-square">
                <img
                  src={product.src}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-6">
                <h3 className="text-white font-semibold text-lg mb-1">{product.name}</h3>
                <p className="text-white/40 text-xs font-light mb-1">{product.medium}</p>
                <p className="text-white/40 text-xs font-light mb-4">{product.size}</p>
                <div className="flex items-center justify-between">
                  <span className="text-white font-bold text-xl">{product.price}</span>
                  <a
                    href={product.wa}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-white text-black text-sm font-semibold hover:bg-white/90 transition-all duration-200"
                  >
                    <ShoppingBag size={14} />
                    Order
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        <p className="text-center text-white/30 text-sm mt-12 font-light">
          Pengiriman ke seluruh Indonesia &bull; Custom order tersedia
        </p>
      </div>
    </section>
  );
}
