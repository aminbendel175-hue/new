export default function Hero() {
  return (
    <section
      id="home"
      className="relative h-screen flex flex-col items-center justify-center text-center overflow-hidden"
    >
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage:
            "url('https://images.pexels.com/photos/1616403/pexels-photo-1616403.jpeg?auto=compress&cs=tinysrgb&w=1920')",
        }}
      />
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/55" />

      <div className="relative z-10 px-6 max-w-3xl mx-auto">
        <p className="text-white/60 text-sm tracking-[0.3em] uppercase mb-6 font-light">
          Original Art Collection
        </p>
        <h1 className="text-white text-5xl md:text-7xl font-bold leading-tight mb-6">
          Art That Speaks<br />
          <span className="italic font-light">Without Words</span>
        </h1>
        <p className="text-white/70 text-base md:text-lg font-light mb-10">
          Setiap karya punya cerita
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="#gallery"
            className="px-8 py-3 rounded-full bg-white text-black text-sm font-semibold tracking-wider hover:bg-white/90 transition-all duration-200 hover:shadow-[0_0_30px_rgba(255,255,255,0.3)]"
          >
            Explore Gallery
          </a>
          <a
            href="#shop"
            className="px-8 py-3 rounded-full border border-white/40 text-white text-sm font-light tracking-wider hover:border-white hover:bg-white/10 transition-all duration-200"
          >
            Shop Now
          </a>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
        <div className="w-px h-10 bg-white/30" />
        <p className="text-white/40 text-xs tracking-widest uppercase">Scroll</p>
      </div>
    </section>
  );
}
