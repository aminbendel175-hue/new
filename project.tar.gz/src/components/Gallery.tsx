import { useState } from 'react';
import { X } from 'lucide-react';

const artworks = [
  {
    id: 1,
    title: 'Abstract 1',
    medium: 'Acrylic on Canvas',
    year: '2025',
    src: 'https://images.pexels.com/photos/1193743/pexels-photo-1193743.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
  {
    id: 2,
    title: 'Abstract 2',
    medium: 'Oil on Canvas',
    year: '2025',
    src: 'https://images.pexels.com/photos/2110951/pexels-photo-2110951.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
  {
    id: 3,
    title: 'Abstract 3',
    medium: 'Watercolor',
    year: '2024',
    src: 'https://images.pexels.com/photos/1585325/pexels-photo-1585325.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
  {
    id: 4,
    title: 'Abstract 4',
    medium: 'Mixed Media',
    year: '2024',
    src: 'https://images.pexels.com/photos/3246665/pexels-photo-3246665.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
  {
    id: 5,
    title: 'Abstract 5',
    medium: 'Acrylic on Canvas',
    year: '2026',
    src: 'https://images.pexels.com/photos/1509534/pexels-photo-1509534.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
  {
    id: 6,
    title: 'Abstract 6',
    medium: 'Digital Art',
    year: '2026',
    src: 'https://images.pexels.com/photos/1647962/pexels-photo-1647962.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
];

export default function Gallery() {
  const [selected, setSelected] = useState<(typeof artworks)[0] | null>(null);

  return (
    <section id="gallery" className="py-28 px-6 lg:px-10 bg-[#0f0f0f]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-white/40 text-xs tracking-[0.3em] uppercase mb-4">Portfolio</p>
          <h2 className="text-white text-4xl md:text-5xl font-bold">Gallery</h2>
          <div className="w-16 h-px bg-white/20 mx-auto mt-6" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {artworks.map((art) => (
            <div
              key={art.id}
              className="group relative overflow-hidden rounded-xl cursor-pointer aspect-square"
              onClick={() => setSelected(art)}
            >
              <img
                src={art.src}
                alt={art.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute bottom-0 left-0 right-0 p-5 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                <p className="text-white font-semibold text-lg">{art.title}</p>
                <p className="text-white/60 text-sm font-light">{art.medium} · {art.year}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {selected && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setSelected(null)}
        >
          <button
            className="absolute top-6 right-6 text-white/60 hover:text-white transition-colors"
            onClick={() => setSelected(null)}
          >
            <X size={28} />
          </button>
          <div
            className="max-w-3xl w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={selected.src}
              alt={selected.title}
              className="w-full rounded-xl object-contain max-h-[75vh]"
            />
            <div className="mt-4 text-center">
              <p className="text-white font-semibold text-xl">{selected.title}</p>
              <p className="text-white/50 text-sm font-light mt-1">{selected.medium} · {selected.year}</p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
